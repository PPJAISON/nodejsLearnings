var express = require('express');
var routes = function(Book){
var bookRouter = express.Router();
bookRouter.route('/')
    .post(function(req,res){
        var book = new Book(req.body);
        book.save();
        console.log(book);
        res.send(book);
    })
    .get(function (req, res) {
        var query = req.query;
        Book.find(query,function(err,books){
            if (err){
                    console.log(err);
                    res.status(500).send(err);
                }
            else res.json(books);
        });
    });

bookRouter.route('/:bookId')
    .get(function (req, res) {
        Book.findById(req.params.bookId,function(err,book){
            if (err){
                    console.log(err);
                    res.status(500).send(err);
                }
            else res.json(book);
        });
    });


    return bookRouter;
};
module.exports = routes;
